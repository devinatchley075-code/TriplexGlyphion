```markdown
# Copilot Hints

- Always normalize filenames to NFC before deterministic sorting.
- Use external sort (system `sort` or external-sort package) when entry count > spill threshold to avoid OOM on CI.
- Ensure SOURCE_DATE_EPOCH is set when compiling LaTeX/PDF for deterministic output.
- Lock updates must use dedicated scripts:
  - pnpm run spec:update
  - pnpm run metrics:update
```