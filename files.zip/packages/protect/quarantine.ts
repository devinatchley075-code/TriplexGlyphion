import fs from 'fs';
import path from 'path';
import { createHash } from 'crypto';
import { promises as pfs } from 'fs';

export async function quarantineWrite(destDir: string, data: Buffer): Promise<{ sha: string; path: string }> {
  await pfs.mkdir(destDir, { recursive: true });
  const sha = createHash('sha256').update(data).digest('hex');
  const filePath = path.join(destDir, sha);
  try {
    await pfs.writeFile(filePath, data, { flag: 'wx' }); // fail if exists
  } catch (e: any) {
    // if file already exists, treat as success (idempotent)
    if (e.code !== 'EEXIST') throw new Error('TG_0005: quarantine write error: ' + e.message);
  }
  return { sha, path: filePath };
}