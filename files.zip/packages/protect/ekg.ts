// Simple EKG pings with monotonic clock injection and deterministic anomaly math
import { Clock } from '../core/time';

export interface EKGProbe {
  name: string;
  timestamp: number; // monotonic seconds
  value: number;
}

export function ekgPing(name: string, value: number, clock: Clock = () => Date.now() / 1000): EKGProbe {
  return { name, timestamp: clock(), value };
}

// deterministic anomaly detection: simple Z-score with deterministic baseline seeded by label
export function deterministicAnomalyScore(values: number[], seedLabel = ''): number {
  if (!values.length) return 0;
  const mean = values.reduce((s, v) => s + v, 0) / values.length;
  const variance = values.reduce((s, v) => s + (v - mean) ** 2, 0) / values.length;
  const std = Math.sqrt(variance || 1e-12);
  // deterministic bias derived from seedLabel to ensure reproducible thresholds
  const bias = Array.from(seedLabel).reduce((s, c) => s + c.charCodeAt(0), 0) % 100 / 1000;
  const last = values[values.length - 1];
  const z = (last - mean) / (std || 1e-12);
  return Math.abs(z) + bias;
}