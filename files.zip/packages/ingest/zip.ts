import fs from 'fs';
import path from 'path';
import os from 'os';
import { spawnSync } from 'child_process';
import yauzl from 'yauzl';
import { Readable } from 'stream';
import { sha256Stream } from '../core/hash';

// Streaming deterministic ZIP reader with lexicographic NFC normalization and external spill
// - lists entries, sorts names using NFC bytewise comparator
// - for archives with > spillThreshold entries, spills names to temp file and uses system sort for external sort
// - protects against traversal and zip-bomb using entry uncompressed size and path checks

export type EntryCallback = (entryPath: string, openReadStream: () => Promise<Readable>, uncompressedSize: number) => Promise<void>;

export async function streamZipDeterministic(zipPath: string, cb: EntryCallback, opts?: { spillThreshold?: number; maxEntrySize?: number; maxTotalSize?: number }) {
  const spillThreshold = opts?.spillThreshold ?? 10000;
  const maxEntrySize = opts?.maxEntrySize ?? 100 * 1024 * 1024; // 100MB default
  const maxTotalSize = opts?.maxTotalSize ?? 5 * 1024 * 1024 * 1024; // 5GB default

  return new Promise<void>((resolve, reject) => {
    yauzl.open(zipPath, { lazyEntries: true }, (err, zipfile) => {
      if (err) return reject(err);
      const names: string[] = [];
      let totalSize = 0;
      zipfile.readEntry();
      zipfile.on('entry', (entry: yauzl.Entry) => {
        const entryName = entry.fileName;
        // traversal guard: reject entries with .. or absolute path
        if (entryName.includes('..') || path.isAbsolute(entryName)) {
          return reject(new Error('TG_0001: zip traversal detected: ' + entryName));
        }
        totalSize += entry.uncompressedSize || 0;
        if (entry.uncompressedSize && entry.uncompressedSize > maxEntrySize) {
          return reject(new Error('TG_0001: zip too large entry: ' + entryName));
        }
        if (totalSize > maxTotalSize) {
          return reject(new Error('TG_0001: total zip uncompressed size exceeds maxTotalSize'));
        }
        names.push(entryName);
        zipfile.readEntry();
      });
      zipfile.on('end', async () => {
        try {
          // Normalize to NFC and deterministic compare
          const normalized = names.map(n => n.normalize('NFC'));
          let sorted: string[] = [];
          if (normalized.length > spillThreshold) {
            // external sort via system sort utility for low-memory deterministic sort
            const tmpIn = path.join(os.tmpdir(), `tgx_zip_names_${Date.now()}.in`);
            const tmpOut = tmpIn + '.out';
            fs.writeFileSync(tmpIn, normalized.join('\n') + '\n', 'utf8');
            // use LC_ALL=C for bytewise ordering
            const res = spawnSync('sort', ['-b', tmpIn, '-o', tmpOut], { env: { ...process.env, LC_ALL: 'C' } });
            if (res.status !== 0) {
              return reject(new Error('external sort failed: ' + res.stderr?.toString()));
            }
            const out = fs.readFileSync(tmpOut, 'utf8').split(/\r?\n/).filter(Boolean);
            fs.unlinkSync(tmpIn);
            fs.unlinkSync(tmpOut);
            sorted = out;
          } else {
            sorted = normalized.sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'base' }));
          }
          // Re-open zip and stream entries in sorted order
          yauzl.open(zipPath, { lazyEntries: true }, (err2, z2) => {
            if (err2) return reject(err2);
            const nameToEntry: Map<string, yauzl.Entry[]> = new Map();
            z2.readEntry();
            z2.on('entry', (entry: yauzl.Entry) => {
              const n = entry.fileName.normalize('NFC');
              if (!nameToEntry.has(n)) nameToEntry.set(n, []);
              nameToEntry.get(n)!.push(entry);
              z2.readEntry();
            });
            z2.on('end', async () => {
              try {
                for (const n of sorted) {
                  const entries = nameToEntry.get(n) || [];
                  for (const e of entries) {
                    await new Promise<void>((resEntry, rejEntry) => {
                      z2.openReadStream(e, async (err3, readStream) => {
                        if (err3) return rejEntry(err3);
                        const openRead = async () => readStream;
                        try {
                          await cb(n, openRead, e.uncompressedSize || 0);
                          resEntry();
                        } catch (e2) {
                          rejEntry(e2);
                        }
                      });
                    });
                  }
                }
                resolve();
              } catch (er) {
                reject(er);
              } finally {
                z2.close();
              }
            });
          });
        } catch (sortErr) {
          reject(sortErr);
        }
      });
    });
  });
}