// GLPI v1: lineage-weighted Damerau–Levenshtein distance normalized to [0..1]
// costs configurable and configurable lineage weights
export interface GLPIOptions {
  insertionCost?: number;
  deletionCost?: number;
  substitutionCost?: number;
  transpositionCost?: number;
  weightFn?: (pos: number) => number; // function to compute lineage weight for each position
}

export function damerauLevenshteinRatio(a: string, b: string, opts?: GLPIOptions): number {
  const ins = opts?.insertionCost ?? 1;
  const del = opts?.deletionCost ?? 1;
  const sub = opts?.substitutionCost ?? 1;
  const trans = opts?.transpositionCost ?? 1;

  const alen = a.length;
  const blen = b.length;
  if (alen === 0 && blen === 0) return 1;
  // compute distance matrix
  const INF = alen + blen;
  const H: number[][] = Array.from({ length: alen + 2 }, () => Array(blen + 2).fill(0));
  H[0][0] = INF;
  for (let i = 0; i <= alen; i++) {
    H[i + 1][0] = INF;
    H[i + 1][1] = i;
  }
  for (let j = 0; j <= blen; j++) {
    H[0][j + 1] = INF;
    H[1][j + 1] = j;
  }
  const da: Record<string, number> = {};
  for (let i = 1; i <= alen; i++) {
    let db = 0;
    for (let j = 1; j <= blen; j++) {
      const i1 = da[b[j - 1]] ?? 0;
      const j1 = db;
      let cost = (a[i - 1] === b[j - 1]) ? 0 : sub;
      if (cost === 0) db = j;
      H[i + 1][j + 1] = Math.min(
        H[i][j] + cost,
        H[i + 1][j] + ins,
        H[i][j + 1] + del,
        H[i1][j1] + (i - i1 - 1) * del + trans + (j - j1 - 1) * ins
      );
    }
    da[a[i - 1]] = i;
  }
  const distance = H[alen + 1][blen + 1];
  // Normalize to [0..1] where 1 is identical and 0 is maximally different
  const maxCost = Math.max(alen * Math.max(ins, sub), blen * Math.max(ins, sub));
  const ratio = 1 - (distance / (alen + blen || 1));
  // Clamp
  return Math.max(0, Math.min(1, ratio));
}

export function glpiScore(a: string, b: string, lineageWeights?: number[], opts?: GLPIOptions): number {
  // combine string similarity and lineage weighting
  const base = damerauLevenshteinRatio(a, b, opts);
  if (!lineageWeights || lineageWeights.length === 0) return base;
  // apply simple weighted mean where later positions may have different weights
  const len = Math.max(lineageWeights.length, 1);
  const wsum = lineageWeights.reduce((s, x) => s + x, 0) || 1;
  const wmean = lineageWeights.reduce((s, x) => s + x, 0) / wsum;
  // blend: base^weightedMean to penalize low lineage weight
  const res = Math.pow(base, 1 / Math.max(0.0001, wmean));
  return Math.max(0, Math.min(1, res));
}