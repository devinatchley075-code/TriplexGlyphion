#!/usr/bin/env python3
"""
tools/experiments/run_all_v6.py

Example experiment runner (deterministic seed support).

Usage:
  python tools/experiments/run_all_v6.py --seed 42 --input data/input.json --out artifacts/exp.json

The script is deterministic given same inputs and seed; it prints a canonical JSON results object.
"""
import argparse
import json
import hashlib
import random
import sys

def sha256_bytes(b: bytes):
    return hashlib.sha256(b).hexdigest()

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--input', required=True)
    p.add_argument('--out', required=True)
    args = p.parse_args()
    random.seed(args.seed)
    data = json.load(open(args.input, 'r'))
    results = {
        "seed": args.seed,
        "input_count": len(data.get('items', [])),
        "rand_sample": random.random(),
    }
    out_json = json.dumps(results, sort_keys=True, indent=2)
    open(args.out, 'w').write(out_json)
    print(out_json)

if __name__ == '__main__':
    main()