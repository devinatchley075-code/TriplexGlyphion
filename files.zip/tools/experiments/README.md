```markdown
# Experiment runner: run_all_v6.py

Inputs:
- JSON input with key "items": list

Outputs:
- A deterministic JSON at the --out path when run with the same --seed and same input.

Determinism notes:
- Pass an explicit integer --seed to ensure deterministic pseudo-random behavior.
- The runner computes no external timestamps; to reproduce, use the same Python runtime version and same input file bytes.

Example:
python tools/experiments/run_all_v6.py --seed 123 --input fixtures/example_items.json --out artifacts/exp_v6.json
```