#!/usr/bin/env tsx
/**
 * tools/metrics-lock.ts
 *
 * Metrics peak lock enforcement.
 *
 * Usage:
 *  pnpm run metrics:check
 *  pnpm run metrics:update
 *
 * Expects an artifacts/metrics.json produced by the test run.
 */
import fs from "fs";
import { createHash } from "crypto";
import path from "path";

const metricsLockPath = "metrics.lock.json";
const metricsPath = path.join("artifacts", "metrics.json"); // CI should write here

function sha256Of(buf: Buffer) {
  return createHash("sha256").update(buf).digest("hex");
}

function withinPeak(actual: unknown, peak: number, tol = 0.002) {
  if (typeof actual !== "number") return false;
  return actual >= peak || Math.abs(actual - peak) <= tol;
}

function check() {
  if (!fs.existsSync(metricsLockPath)) {
    console.error("TG_0004: metrics.lock.json missing. Run 'pnpm run metrics:update' to create it.");
    process.exit(1);
  }
  if (!fs.existsSync(metricsPath)) {
    console.error("TG_0004: metrics artifact not found:", metricsPath);
    process.exit(1);
  }
  const metrics = JSON.parse(fs.readFileSync(metricsPath, "utf-8"));
  const locked = JSON.parse(fs.readFileSync(metricsLockPath, "utf-8"));

  const currentSha = sha256Of(Buffer.from(JSON.stringify(metrics)));
  if (locked.sha256 !== currentSha) {
    console.error("TG_0004: Metrics hash mismatch. Run 'pnpm run metrics:update' to update lockfile.");
    process.exit(1);
  }

  const ers = metrics.ERS ?? null;
  const sis = metrics.SIS ?? null;
  const glpi = metrics.GLPI ?? null;

  const peaks = { ers: 0.31, sis: 0.86, glpi: 0.78 };
  if (!withinPeak(ers, peaks.ers) || !withinPeak(sis, peaks.sis) || !withinPeak(glpi, peaks.glpi)) {
    console.error("TG_0004: One or more metric peaks failed (ERS/SIS/GLPI).", { ers, sis, glpi, peaks });
    process.exit(1);
  }

  console.log("Metrics verified OK.");
  process.exit(0);
}

function update() {
  if (!fs.existsSync(metricsPath)) {
    console.error("metrics artifact not found:", metricsPath);
    process.exit(1);
  }
  const metrics = fs.readFileSync(metricsPath);
  const lock = {
    file: metricsPath,
    sha256: sha256Of(metrics),
    updated_at: new Date().toISOString()
  };
  fs.writeFileSync(metricsLockPath, JSON.stringify(lock, null, 2) + "\n");
  console.log("metrics.lock.json updated.");
  process.exit(0);
}

const arg = process.argv[2] || "check";
if (arg === "update") update();
else check();