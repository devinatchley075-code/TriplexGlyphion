```markdown
# Security Guidelines

- Deterministic builds: set SOURCE_DATE_EPOCH before PDF build.
- Zip ingestion guardrails:
  - reject entries with traversal (.. or absolute paths)
  - enforce per-entry and total uncompressed size limits
  - require deterministic NFC normalization for ordering
- Quarantine: content-addressed by sha256; writes must be idempotent.
- Sanitize fixtures: ensure no secrets inside fixtures/tgx_a3_vault_example_hooked.json.
```