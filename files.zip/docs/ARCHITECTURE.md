```markdown
# Architecture Overview

High-level overview of packages and interactions:

- packages/core: core primitives (hashing, merkle, time, result)
- packages/ingest: deterministic streaming ingest (zip, vfs, extract)
- packages/compression: tokenization and semantic mapping
- packages/audit: ERS/SIS/GLPI audit metrics
- packages/protect: EKG, anomaly detection, quarantine

Images:
- docs/img/energy_vectoring_example.png
- docs/img/fig_crp_r2.png
- docs/img/fig_wss_tasks.png

Papers:
- docs/papers/TriplexGlyphion_SEPAL_GlyphForge.pdf

Please ensure the assets above are added to the repository under the referenced paths.
``` 