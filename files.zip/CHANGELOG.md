```markdown
# Changelog

## [v1.3] - 2025-09-15
### Added
- Core primitives: hash.ts, merkle.ts, result.ts, time.ts
- Ingest: deterministic streaming ZIP with external spill and guardrails
- Compression: tokenization and semantic mapping baseline (stubs)
- Audit: GLPI v1 (lineage-weighted DL) implementation
- Protect: EKG pings, deterministic anomaly math, quarantine
- CI: metrics and spec lock enforcement
- docs/triplexglyphion_math_spec.tex and spec.lock.json
```